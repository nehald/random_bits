import pika
import json


def basic_publish(channel, method_frame, header_frame, body):
    print 'basic_publish'
    try:
        channel.basic_publish(exchange='', routing_key=header_frame.reply_to,
                             properties=pika.BasicProperties(correlation_id=
                             header_frame.correlation_id), body=data)
    except:
        pass
       ###  channel ack msg_q
        channel.basic_ack(delivery_tag=method_frame.delivery_tag)


## callback function for the consume
def on_message(channel, method_frame, header_frame, body):
    print body 
    try:
        body_info = ('json', json.loads(body))
    except:
        body_info = ('str', body)

    (data_type, data) = body_info
    if data_type == 'json':
        try:
            cm_channels = body_dict['channels'].split(",")
            cm_pos = body_dict['pos']
        except:
            pass
    ## push info to data channels
    basic_publish(channel, method_frame, header_frame, body)


connection = pika.BlockingConnection()
channel = connection.channel()


## listen to msq_q. When something comes in
## do something with the data
channel.basic_consume(on_message, 'msg_q')
try:
    print 'channel.start_consuming'
    channel.start_consuming()
except KeyboardInterrupt:
    channel.stop_consuming()
