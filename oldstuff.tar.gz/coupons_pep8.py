from tornado import ioloop
from tornado import httpclient
import json
import pprint
from factual import Factual

a = []

def get_factual_coupons(pos):

    pos_array = list(pos)
	try:
    		factual = Factual("mv9zkX2MfQqco84sTTcjQQ5CpoSy00w13fsmkOGu",
                      		"AiEEeBP2Ie0G1gjlohrx9e1PFFTgRPeV6caM1pGs")
    		monetize = factual.monetize()
    		factual_coupons = monetize.geo({"$circle": {"$center": [33.91914, -
                		118.4163], "$meters": 800}}).data()
		return factual_coupons
	except:
		print 'Error in factual_coupons'
		    

return factual_coupons


def get_yipit_coupons(pos):
    lat, lon = pos
    lat_string = "&lat=" + str(lat)
    lon_string = "&lon=" + str(lon)
    yipit2 = "http://api.yipit.com/v1/deals/?key=Ev8xdSw69ewNxMr4&lat=33.9120788&lon=-118.419164&radius=1"
    yipit = "http://api.yipit.com/v1/deals/?key=Ev8xdSw69ewNxMr4" + \
            lat_string + lon_string + "&radius=1"
    http_client = httpclient.AsyncHTTPClient()
    http_client.fetch(yipit, handle_request)


def handle_request(response):
    print 'handle'
    if response.error:
        print "Error:", response.error
    else:
        rb = json.loads(response.body)
    for r in rb['response']['deals']:
        a.append(r)
    print a


pos = (33.91914, -118.4163)
yipit_str = get_yipit_coupons(pos)
## get factual coupons
# coupons = get_factual_coupons(pos);
# print pprint.pprint(coupons)
ioloop.IOLoop.instance().start()
