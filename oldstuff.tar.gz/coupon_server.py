import urllib
import json
import pymongo
import sys
#sys.path.append("/home/nehal/ganglia/damit/sensorprocessing/utils")
import dataChannel
import daemon

class CouponChannel(dataChannel.dataChannel):
    def __init__(self, servername, queuename, tags="fdsadf"):
        dataChannel.dataChannel.__init__(self, servername, queuename)

    def handle_delivery(self, channel, method_frame, header_frame, body):
        channel.basic_ack(delivery_tag=method_frame.delivery_tag)
        try:
            request = json.loads(body)
            pos = request['pos']
        except:
            print 'fd'
            pass;         
        return 0; 

###  GenericServer(current server name,next server)
def main():
    port = 80 
    print 'sdfafdafasdfasdfasd' 
    gps = CouponChannel("coupon_server", "coupon_q", 'mongodb,archiving')
    gps.connect()
    gps.connection = gps.get_connection()
    log = open('tornado.' + str(port) + '.log', 'a+')
#    ctx = daemon.DaemonContext(stdout=log, stderr=log,  working_directory='.')
#    ctx.open()
    gps.connection.ioloop.start()

main()
